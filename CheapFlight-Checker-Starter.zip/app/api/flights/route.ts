import { NextRequest, NextResponse } from "next/server";
export const runtime = "nodejs";
function safeDate(value: string | null) { return !!value && /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(value)); }
export async function GET(request: NextRequest) {
  const {searchParams}=new URL(request.url);
  const origin=(searchParams.get("origin")||"").toUpperCase(), destination=(searchParams.get("destination")||"").toUpperCase();
  const departureDate=searchParams.get("departureDate"), returnDate=searchParams.get("returnDate");
  const adults=Number(searchParams.get("adults")||"1"), currency=(searchParams.get("currency")||"USD").toUpperCase();
  if(!/^[A-Z]{3}$/.test(origin)||!/^[A-Z]{3}$/.test(destination)||origin===destination)
    return NextResponse.json({error:"กรุณาใส่รหัสสนามบิน 3 ตัวที่ถูกต้องและไม่ซ้ำกัน"},{status:400});
  if(!safeDate(departureDate)||(returnDate&&(!safeDate(returnDate)||returnDate<departureDate!)))
    return NextResponse.json({error:"กรุณาตรวจสอบวันเดินทาง"},{status:400});
  if(!Number.isInteger(adults)||adults<1||adults>9||!["USD","THB","EUR"].includes(currency))
    return NextResponse.json({error:"จำนวนผู้โดยสารหรือสกุลเงินไม่ถูกต้อง"},{status:400});
  const clientId=process.env.AMADEUS_CLIENT_ID, clientSecret=process.env.AMADEUS_CLIENT_SECRET;
  const baseUrl=process.env.AMADEUS_BASE_URL||"https://test.api.amadeus.com";
  if(!clientId||!clientSecret) return NextResponse.json({error:"ยังไม่ได้ตั้งค่า API credentials ใน Environment Variables ของโฮสต์"},{status:503});
  try {
    const tokenResponse=await fetch(`${baseUrl}/v1/security/oauth2/token`,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({grant_type:"client_credentials",client_id:clientId,client_secret:clientSecret}),cache:"no-store"});
    const tokenData=await tokenResponse.json();
    if(!tokenResponse.ok||!tokenData.access_token) return NextResponse.json({error:"เข้าสู่ระบบผู้ให้บริการเที่ยวบินไม่สำเร็จ ตรวจสอบ credentials และโหมด Test/Production"},{status:502});
    const query=new URLSearchParams({originLocationCode:origin,destinationLocationCode:destination,departureDate:departureDate!,adults:String(adults),currencyCode:currency,max:"50"});
    if(returnDate) query.set("returnDate",returnDate);
    const response=await fetch(`${baseUrl}/v2/shopping/flight-offers?${query.toString()}`,{headers:{Authorization:`Bearer ${tokenData.access_token}`},cache:"no-store"});
    const data=await response.json();
    if(!response.ok) return NextResponse.json({error:data?.errors?.[0]?.detail||data?.errors?.[0]?.title||"ค้นหาราคาไม่สำเร็จ"},{status:502});
    const flights=(data.data||[]).map((offer:any)=>({id:offer.id,price:offer.price,itineraries:offer.itineraries,validatingAirlineCodes:offer.validatingAirlineCodes,numberOfBookableSeats:offer.numberOfBookableSeats,bookingUrl:`https://www.google.com/travel/flights?q=${encodeURIComponent(`Flights from ${origin} to ${destination} on ${departureDate}${returnDate?` returning ${returnDate}`:""}`)}`})).sort((a:any,b:any)=>Number(a.price?.total||Infinity)-Number(b.price?.total||Infinity));
    return NextResponse.json({flights,source:"Amadeus Self-Service API",searchedAt:new Date().toISOString()});
  } catch { return NextResponse.json({error:"เชื่อมต่อบริการค้นหาไม่ได้ชั่วคราว กรุณาลองใหม่"},{status:502}); }
}
